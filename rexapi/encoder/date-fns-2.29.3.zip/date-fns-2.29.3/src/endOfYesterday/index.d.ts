// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { endOfYesterday } from 'date-fns'
export default endOfYesterday
