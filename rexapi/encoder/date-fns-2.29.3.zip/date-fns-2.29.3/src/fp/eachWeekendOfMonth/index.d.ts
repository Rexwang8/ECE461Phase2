// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { eachWeekendOfMonth } from 'date-fns/fp'
export default eachWeekendOfMonth
