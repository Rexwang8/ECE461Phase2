/** Used to match template delimiters. */
const reEscape = /<%-([\s\S]+?)%>/g

export default reEscape
