// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { differenceInMonths } from 'date-fns/fp'
export default differenceInMonths
