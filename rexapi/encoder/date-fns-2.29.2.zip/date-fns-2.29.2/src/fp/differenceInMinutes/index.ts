// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import fn from '../../differenceInMinutes/index'
import convertToFP from '../_lib/convertToFP/index'

export default convertToFP(fn, 2)
