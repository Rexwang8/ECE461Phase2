// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { addQuarters } from 'date-fns'
export default addQuarters
