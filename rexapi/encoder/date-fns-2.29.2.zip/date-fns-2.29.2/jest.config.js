module.exports = {
  verbose: false,
  testPathIgnorePatterns: ['<rootDir>/test.js'],
}
