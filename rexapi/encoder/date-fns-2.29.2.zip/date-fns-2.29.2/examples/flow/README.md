# Usage With flow

See [example.js.flow](./example.js.flow), [fp.js.flow](./fp.js.flow) and [misc.js.flow](./misc.js.flow) for source code examples.

See [package.json scripts](./package.json) for CLI usage.

## Build Example

```sh
yarn
yarn run build
```
