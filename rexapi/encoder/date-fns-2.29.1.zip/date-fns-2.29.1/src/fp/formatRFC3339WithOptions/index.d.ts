// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

import { formatRFC3339WithOptions } from 'date-fns/fp'
export default formatRFC3339WithOptions
