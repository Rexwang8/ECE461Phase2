// This file is generated automatically by `scripts/build/typings.js`. Please, don't change it.

export const daysInWeek: number
export const daysInYear: number
export const maxTime: number
export const millisecondsInMinute: number
export const millisecondsInHour: number
export const millisecondsInSecond: number
export const minTime: number
export const minutesInHour: number
export const monthsInQuarter: number
export const monthsInYear: number
export const quartersInYear: number
export const secondsInHour: number
export const secondsInMinute: number
export const secondsInDay: number
export const secondsInWeek: number
export const secondsInYear: number
export const secondsInMonth: number
export const secondsInQuarter: number
