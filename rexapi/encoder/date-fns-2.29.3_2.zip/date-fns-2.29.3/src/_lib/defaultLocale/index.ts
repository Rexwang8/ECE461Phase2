import defaultLocale from '../../locale/en-US/index'
export default defaultLocale
