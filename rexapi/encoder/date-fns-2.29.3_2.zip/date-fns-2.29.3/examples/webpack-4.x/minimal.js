import { toDate } from 'date-fns'

console.log(toDate(null).toString() === 'Invalid Date')
